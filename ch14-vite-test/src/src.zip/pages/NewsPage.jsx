import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import Categories from '../components/Categories.jsx';
import NewsList from '../components/NewsList.jsx';

const VALID = new Set([
  'busanFood',
  'festival',
  'airAlert',
  'population',
  'village',
]);

const NewsPage = () => {
  const params = useParams();
  const category = params.category;

  // 기본값/예외 처리: 유효하지 않으면 명소로 리다이렉트
  if (!category || !VALID.has(category)) {
    return <Navigate to="/busanFood" replace />;
  }

  return (
    <div>
      <Categories />
      <NewsList category={category} />
    </div>
  );
};

export default NewsPage;
