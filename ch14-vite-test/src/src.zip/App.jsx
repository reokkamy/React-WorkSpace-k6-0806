import './App.css';
import React from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';
import NewsPage from './pages/NewsPage.jsx';

function App() {
  return (
    <div>
      <h1 className="react">부산 정보 알림창 </h1>
      <Routes>
        Route path="/" element={<Navigate to="/busanFood" replace />} />
        <Route path="/:category" element={<NewsPage />} />
      </Routes>
    </div>
  );
}

export default App;
