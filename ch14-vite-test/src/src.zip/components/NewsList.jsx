import { useState, useEffect } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import usePromise from '../lib/usePromise.jsx';

import PdItemFood from './PdItemFood.jsx';
import PdItemFestival from './PdItemFestival.jsx';
import PanelAirAlert from './PanelAirAlert.jsx';
import PanelPopulation from './PanelPopulation.jsx';
import PanelVillage from './PanelVillage.jsx';

//css 작업
const NewsListBlock = styled.div`
  box-sizing: border-box;
  padding-bottom: 3rem;
  width: 768px;
  margin: 0 auto;
  margin-top: 2rem;
  @media screen and (max-width: 768px) {
    width: 100%;
    padding-left: 1rem;
    padding-right: 1rem;
  }
`;

// 공공데이터: 명소/맛집 두 서비스만 사용
// (기존 newsapi 관련 로직 전부 제거)
const SERVICE_KEY =
  'WpZMbiL8V/K0fsPY+Lrv3CAmv9bYQZlIaSb2wM4JQ26YOraocdJOCvXhV7m/N/gW6b4u5II/du5rpgm6cjnN7w==';

const endpoints = {
  // 2) 부산맛집(기존)
  busanFood: {
    url: `/api-busan/6260000/FoodService/getFoodKr`,
    params: {
      serviceKey: SERVICE_KEY,
      numOfRows: 100,
      pageNo: 1,
      resultType: 'json',
    },
    pick: (res) => res?.data?.getFoodKr?.item ?? [],
    Item: PdItemFood,
  },
  // 3) 축제정보(부산 데이터 포털의 축제 서비스 경로로 교체)
  festival: {
    // 예시: /6260000/FestivalService/getFestivalKr (실제 서비스명 확인해서 교체)
    url: `/api-busan/6260000/FestivalService/getFestivalKr`,
    params: {
      serviceKey: SERVICE_KEY,
      numOfRows: 100,
      pageNo: 1,
      resultType: 'json',
    },
    pick: (res) => res?.data?.getFestivalKr?.item ?? [],
    Item: PdItemFestival,
  },
  // 4) 미세먼지 경보(환경부 AirKorea - 서비스명/파라미터 확인)
  airAlert: {
    // 예시: /B552584/ArpltnInforInqireSvc/getUlfptcaAlarmInfo (경보 조회 계열)
    url: `/api-busan/6260000/FestivalService/getFestivalKr`,
    params: {
      serviceKey: SERVICE_KEY,
      returnType: 'json',
      numOfRows: 100,
      pageNo: 1,
    },
    pick: (res) => res?.data?.response?.body?.items ?? [],
    Item: PanelAirAlert,
  },
  // 5) 인구동태(기관/서비스 확인 필요: 부산통계/행안부/통계청 등)
  population: {
    url: `/api-pop/3076630/v1/population`,
    params: {
      page: 1,
      perPage: 10,
      serviceKey: SERVICE_KEY, // 디코딩된 키
    },
    pick: (res) => res?.data?.data ?? [], // ODCloud 응답은 { data: [...], meta: {...} }
    Item: PanelPopulation,
  },

  // 6) 동네예보(기상청 초단기/단기/동네예보계열 - nx,ny 또는 좌표 변환 필요)
  village: {
    // 예시: /1360000/VilageFcstInfoService_2.0/getVilageFcst
    url: `/api-kma/1360000/VilageFcstInfoService_2.0/getVilageFcst`,
    params: {
      serviceKey: SERVICE_KEY,
      dataType: 'JSON',
      // base_date, base_time, nx, ny 등은 수업용 기본값/혹은 상단에서 상태로 받기
      base_date: '20250101',
      base_time: '0500',
      nx: 97,
      ny: 74, // 부산 임의 격자 예시(실제 좌표 변환 필요)
      numOfRows: 1000,
      pageNo: 1,
    },
    pick: (res) => res?.data?.response?.body?.items?.item ?? [],
    Item: PanelVillage,
  },
};

const NewsList = ({ category }) => {
  const config = endpoints[category] ?? endpoints.busanFood;
  const sendData = () => axios.get(config.url, { params: config.params });

  const [loading, response, error] = usePromise(sendData, [category]);

  if (loading) {
    return <NewsListBlock>대기중입니다.</NewsListBlock>;
  }
  if (!response) {
    return null;
  }
  if (error) {
    return <NewsListBlock>에러 발생</NewsListBlock>;
  }

  // 데이터 구조 분기
  const data = (endpoints[category]?.pick ?? endpoints.busanFood.pick)(
    response,
  );
  const ItemComp = endpoints[category]?.Item ?? endpoints.busanFood.Item;

  return (
    <NewsListBlock>
      {data.map((it, idx) => (
        <ItemComp
          key={it?.UC_SEQ ?? it?.id ?? it?.ALERT_SN ?? idx}
          article={it}
        />
      ))}
    </NewsListBlock>
  );
};

export default NewsList;
