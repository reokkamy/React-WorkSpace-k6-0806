export default function PanelPopulation({ article }) {
  // 기관마다 필드명이 다양합니다. 대표 예시 형태:
  const {
    sido,
    sigungu,
    year,
    month,
    population,
    birth,
    death,
    moveIn,
    moveOut,
  } = article ?? {};
  return (
    <div style={{ padding: '0.5rem 0', borderBottom: '1px solid #eee' }}>
      <strong>
        {sido} {sigungu}
      </strong>{' '}
      ({year}.{month})<div>인구: {population ?? '-'}</div>
      <div>
        출생: {birth ?? '-'} / 사망: {death ?? '-'}
      </div>
      <div>
        전입: {moveIn ?? '-'} / 전출: {moveOut ?? '-'}
      </div>
    </div>
  );
}
