import styled from 'styled-components';
const Block = styled.div`
  & + & {
    margin-top: 2rem;
  }
`;
export default function PdItemFestival({ article }) {
  const { MAIN_TITLE, ADDR1, ITEMCNTNTS, MAIN_IMG_THUMB, HOMEPAGE_URL } =
    article ?? {};
  return (
    <Block>
      <h2>축제명: {MAIN_TITLE}</h2>
      {ADDR1 && <div>주소: {ADDR1}</div>}
      {ITEMCNTNTS && <p>{ITEMCNTNTS}</p>}
      {HOMEPAGE_URL && (
        <a href={HOMEPAGE_URL} target="_blank" rel="noreferrer">
          홈페이지
        </a>
      )}
      {MAIN_IMG_THUMB && (
        <div>
          <img src={MAIN_IMG_THUMB} alt="" width={200} />
        </div>
      )}
    </Block>
  );
}
