export default function PanelAirAlert({ article }) {
  // AirKorea 예시 구조: { districtName, issueDate, issueVal, issueGubun, ... }
  const { districtName, issueDate, issueVal, issueGubun, moveName, alertStep } =
    article ?? {};
  return (
    <div style={{ padding: '0.5rem 0', borderBottom: '1px solid #eee' }}>
      <strong>{districtName ?? moveName ?? '지역'}</strong> | 단계:{' '}
      {alertStep ?? issueGubun ?? '-'}
      <div>발령일시: {issueDate ?? '-'}</div>
      <div>지수/농도: {issueVal ?? '-'}</div>
    </div>
  );
}
