export default function PanelVillage({ article }) {
  // 기상청 동네예보: {category:'TMP', fcstDate, fcstTime, fcstValue ...}
  const { category, fcstDate, fcstTime, fcstValue } = article ?? {};
  return (
    <div style={{ padding: '0.5rem 0', borderBottom: '1px solid #eee' }}>
      <strong>{category}</strong> {fcstDate} {fcstTime} → {fcstValue}
    </div>
  );
}
